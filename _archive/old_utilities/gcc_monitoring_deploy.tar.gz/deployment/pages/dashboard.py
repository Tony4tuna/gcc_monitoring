from nicegui import ui
from datetime import datetime
from core.auth import require_login, current_user, logout
from core.db import get_conn
from core.equipment_analysis import calculate_equipment_health_score
from core.alert_system import evaluate_all_alerts
from ui.layout import layout
from core.stats import get_summary_counts


def get_unit_details(unit_id: int) -> dict | None:
    conn = get_conn()
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT ur.*, u.make, u.model, u.serial,
                   pl.address1 as location, c.company as customer
            FROM UnitReadings ur
            JOIN Units u ON ur.unit_id = u.unit_id
            JOIN PropertyLocations pl ON u.location_id = pl.ID
            JOIN Customers c ON pl.customer_id = c.ID
            WHERE ur.unit_id = ?
            ORDER BY ur.reading_id DESC
            LIMIT 1
        """, (unit_id,))
        row = cursor.fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def format_time_ago(ts: str) -> str:
    try:
        dt = datetime.fromisoformat(ts)
        diff = datetime.now() - dt
        s = diff.total_seconds()
        if s < 60:    return f"{int(s)}s ago"
        if s < 3600:  return f"{int(s/60)}m ago"
        if s < 86400: return f"{int(s/3600)}h ago"
        return f"{int(s/86400)}d ago"
    except:
        return "—"


def status_color(mode: str, fault: str = None) -> str:
    if fault:
        return "text-red-500"
    colors = {
        "Cooling":    "text-cyan-400",
        "Heating":    "text-orange-400",
        "Economizer": "text-blue-400",
        "Idle":       "text-gray-400",
        "Off":        "text-gray-600",
    }
    return colors.get(mode, "text-white")


def get_unit_stats():
    """Get current statistics from database"""
    conn = get_conn()
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT 
                u.unit_id,
                u.make,
                u.model,
                ur.mode,
                ur.supply_temp,
                ur.return_temp,
                ur.delta_t,
                ur.discharge_psi,
                ur.suction_psi,
                ur.fault_code,
                ur.unit_status,
                ur.ts,
                ur.v_1,
                ur.v_2,
                ur.v_3,
                ur.compressor_amps,
                pl.address1 as location,
                c.company as customer
            FROM UnitReadings ur
            JOIN Units u ON ur.unit_id = u.unit_id
            JOIN PropertyLocations pl ON u.location_id = pl.ID
            JOIN Customers c ON pl.customer_id = c.ID
            WHERE ur.reading_id IN (
                SELECT MAX(reading_id) FROM UnitReadings GROUP BY unit_id
            )
            ORDER BY u.unit_id
        """)
        
        units = cursor.fetchall()
        online_count = 0
        warning_count = 0
        fault_count = 0
        temps = []
        alerts = []
        alerts_count = 0
        health_data = {}
        
        for row in units:
            reading_dict = dict(row)
            health = calculate_equipment_health_score(reading_dict)
            unit_alerts = evaluate_all_alerts(reading_dict)
            alerts_count += unit_alerts.get('count', 0)
            
            health_data[row['unit_id']] = {
                'score': health['score'],
                'status': health['status'],
                'issues': health['issues']
            }
            
            if health['score'] >= 80:
                online_count += 1
            elif health['score'] >= 60:
                warning_count += 1
            else:
                fault_count += 1
            
            temps.append(float(row['supply_temp']) if row['supply_temp'] else 0)
        
        avg_temp = sum(temps) / len(temps) if temps else 0
        
        return {
            'units': units,
            'online_count': online_count,
            'warning_count': warning_count,
            'fault_count': fault_count,
            'avg_temp': int(avg_temp),
            'health_data': health_data,
                'alerts': alerts,
                'alerts_count': alerts_count
        }
    finally:
        conn.close()


def page():
    if not require_login():
        return

    # Use the unified layout function with logout button (main page)
    with layout("HVAC Dashboard", show_logout=True):
        stats = get_unit_stats()
        summary = get_summary_counts()

        # ── System Overview ─────────────────────────────────────
        with ui.grid(columns=4).classes("gap-2 mb-2"):
            with ui.card().classes("text-center p-3 gcc-card"):
                ui.label("Clients").classes("text-xs").style("color: var(--muted)")
                clients_value = ui.label(str(summary.get('clients', 0))).classes("text-xl font-bold").style("color: var(--accent)")
            with ui.card().classes("text-center p-3 gcc-card"):
                ui.label("Locations").classes("text-xs").style("color: var(--muted)")
                locations_value = ui.label(str(summary.get('locations', 0))).classes("text-xl font-bold").style("color: var(--accent)")
            with ui.card().classes("text-center p-3 gcc-card"):
                ui.label("Equipment").classes("text-xs").style("color: var(--muted)")
                equipment_value = ui.label(str(summary.get('equipment', 0))).classes("text-xl font-bold").style("color: var(--accent)")
            with ui.card().classes("text-center p-3 gcc-card"):
                ui.label("Alerts (latest)").classes("text-xs").style("color: var(--muted)")
                alerts_value = ui.label(str(stats.get('alerts_count', 0))).classes("text-xl font-bold text-yellow-400")

        # ── Quick Stats ──────────────────────────────────────────
        with ui.grid(columns=4).classes("gap-2 mb-2"):
            with ui.card().classes("text-center p-3 gcc-card"):
                ui.label("Online").classes("text-xs").style("color: var(--muted)")
                online_value = ui.label(f"{stats['online_count']}/{len(stats['units'])}").classes("text-xl font-bold").style("color: var(--accent)")
            with ui.card().classes("text-center p-3 gcc-card"):
                ui.label("Warnings").classes("text-xs").style("color: var(--muted)")
                warnings_value = ui.label(stats['warning_count']).classes("text-xl font-bold text-orange-400")
            with ui.card().classes("text-center p-3 gcc-card"):
                ui.label("Alarms").classes("text-xs").style("color: var(--muted)")
                alarms_value = ui.label(stats['fault_count']).classes("text-xl font-bold text-red-500")
            with ui.card().classes("text-center p-3 gcc-card"):
                ui.label("Avg Supply").classes("text-xs").style("color: var(--muted)")
                avg_value = ui.label(f"{stats['avg_temp']} °F").classes("text-xl font-bold text-blue-400")

        # ── Units Table (Spreadsheet Style) ──────────────────────
        columns = [
            {"name": "unit", "label": "Unit", "field": "unit", "align": "left", "sortable": True},
            {"name": "model", "label": "Make/Model", "field": "model", "align": "left", "sortable": True},
            {"name": "location", "label": "Location", "field": "location", "align": "left", "sortable": True},
            {"name": "customer", "label": "Customer", "field": "customer", "align": "left", "sortable": True},
            {"name": "mode", "label": "Mode", "field": "mode", "align": "center", "sortable": True},
            {"name": "health", "label": "Health", "field": "health", "align": "center", "sortable": True},
            {"name": "temp", "label": "Supply Temp", "field": "temp", "align": "center", "sortable": True},
            {"name": "fault", "label": "Fault", "field": "fault", "align": "center", "sortable": True},
            {"name": "actions", "label": "Actions", "field": "actions", "align": "center"},
        ]
        
        rows = []
        for row in stats["units"]:
            d = dict(row)
            uid = d["unit_id"]
            health = stats["health_data"].get(uid, {"score": 0, "status": "Unknown"})
            score = health["score"]
            
            rows.append({
                "unit": f"RTU-{uid}",
                "model": f"{d.get('make','—')} {d.get('model','—')}",
                "location": d.get("location", "—"),
                "customer": d.get("customer", "—"),
                "mode": d.get("mode", "—"),
                "health": f"{score}% ({health['status']})",
                "temp": f"{d.get('supply_temp','—')} °F",
                "fault": d.get("fault_code", "—"),
                "actions": uid,
                "_health_score": score,
                "_fault": d.get("fault_code"),
            })
        
        table = ui.table(
            columns=columns,
            rows=rows,
            row_key="unit",
            pagination={"rowsPerPage": 10, "sortBy": "unit", "descending": False}
        ).classes("w-full gcc-card rounded-lg overflow-hidden")
        table.props("dense bordered")
        
        table.add_slot('body-cell-health', '''
            <q-td :props="props">
                <q-badge :color="props.row._health_score >= 80 ? 'green' : props.row._health_score >= 60 ? 'orange' : 'red'">
                    {{ props.value }}
                </q-badge>
            </q-td>
        ''')
        
        table.add_slot('body-cell-fault', '''
            <q-td :props="props">
                <span :class="props.row._fault ? 'text-red-400' : 'text-green-400'">
                    {{ props.value }}
                </span>
            </q-td>
        ''')
        
        table.add_slot('body-cell-actions', '''
            <q-td :props="props">
                <q-btn flat dense icon="info" color="green" size="sm" @click="$parent.$emit('details', props.row.actions)" />
            </q-td>
        ''')
        
        table.on('details', lambda e: show_unit_details(e.args))

        # ── Auto-refresh (every 30s) ───────────────────────────
        def refresh():
            new_stats = get_unit_stats()
            new_summary = get_summary_counts()

            # Update overview tiles
            clients_value.set_text(str(new_summary.get('clients', 0)))
            locations_value.set_text(str(new_summary.get('locations', 0)))
            equipment_value.set_text(str(new_summary.get('equipment', 0)))
            alerts_value.set_text(str(new_stats.get('alerts_count', 0)))

            # Update quick stats
            online_value.set_text(f"{new_stats['online_count']}/{len(new_stats['units'])}")
            warnings_value.set_text(str(new_stats['warning_count']))
            alarms_value.set_text(str(new_stats['fault_count']))
            avg_value.set_text(f"{new_stats['avg_temp']} °F")

            # Rebuild table rows
            new_rows = []
            for r in new_stats["units"]:
                d = dict(r)
                uid = d["unit_id"]
                health = new_stats["health_data"].get(uid, {"score": 0, "status": "Unknown"})
                score = health["score"]

                new_rows.append({
                    "unit": f"RTU-{uid}",
                    "model": f"{d.get('make','—')} {d.get('model','—')}",
                    "location": d.get("location", "—"),
                    "customer": d.get("customer", "—"),
                    "mode": d.get("mode", "—"),
                    "health": f"{score}% ({health['status']})",
                    "temp": f"{d.get('supply_temp','—')} °F",
                    "fault": d.get("fault_code", "—"),
                    "actions": uid,
                    "_health_score": score,
                    "_fault": d.get("fault_code"),
                })

            table.rows = new_rows
            table.update()

        ui.timer(30.0, refresh)


def show_unit_details(unit_id: int):
    data = get_unit_details(unit_id)
    if not data:
        ui.notify("No data", type="negative")
        return

    health = calculate_equipment_health_score(data)
    alerts = evaluate_all_alerts(data)

    with ui.dialog(value=True) as dlg:
        with ui.card().classes("w-full max-w-3xl").style("background: var(--card)"):
            with ui.row().classes("justify-between items-center mb-2 pb-2").style("border-bottom: 1px solid var(--line)"):
                ui.label(f"RTU-{unit_id} – {data['make']} {data['model']}").classes("text-base font-bold")
                ui.button(icon="close", on_click=dlg.close).props("flat dense size=sm")

            with ui.grid(columns=3).classes("gap-2 mb-2"):
                # Health Score
                with ui.card().classes("text-center p-2").style("background: var(--bg); border: 1px solid var(--line)"):
                    ui.label("Health").classes("text-xs opacity-70")
                    color = "text-green-400" if health["score"] >= 80 else "text-orange-400" if health["score"] >= 60 else "text-red-500"
                    ui.label(str(health["score"])).classes(f"text-2xl font-bold {color}")
                    ui.label(health["status"]).classes("text-xs opacity-70")
                
                # Location
                with ui.card().classes("p-2").style("background: var(--bg); border: 1px solid var(--line)"):
                    ui.label("Location").classes("text-xs opacity-70")
                    ui.label(data["location"]).classes("text-sm font-semibold")
                
                # Customer
                with ui.card().classes("p-2").style("background: var(--bg); border: 1px solid var(--line)"):
                    ui.label("Customer").classes("text-xs opacity-70")
                    ui.label(data["customer"]).classes("text-sm font-semibold")

            # Operating Parameters - Compact 3 column grid
            with ui.card().classes("p-2").style("background: var(--bg); border: 1px solid var(--line)"):
                ui.label("Operating Parameters").classes("text-xs font-semibold mb-1 opacity-70")
                with ui.grid(columns=3).classes("gap-x-3 gap-y-1 text-xs"):
                    for k, label in [
                        ("mode", "Mode"),
                        ("supply_temp", "Supply"),
                        ("return_temp", "Return"),
                        ("delta_t", "ΔT"),
                        ("discharge_psi", "Discharge"),
                        ("suction_psi", "Suction"),
                        ("superheat", "Superheat"),
                        ("subcooling", "Subcool"),
                        ("compressor_amps", "Amps"),
                    ]:
                        v = data.get(k)
                        units_str = '°F' if 'temp' in k or 'heat' in k or 'cool' in k else 'PSI' if 'psi' in k else 'A' if 'amps' in k else ''
                        ui.label(f"{label}: {v} {units_str}" if v is not None else f"{label}: —")

            # Active Alerts
            if alerts.get("all"):
                with ui.card().classes("p-2").style("background: var(--bg); border: 1px solid var(--line)"):
                    ui.label("Active Alerts").classes("text-xs font-semibold mb-1 opacity-70")
                    for a in alerts["all"][:4]:
                        c = "text-red-400" if a["severity"] == "critical" else "text-orange-400"
                        ui.label(f"[{a['severity'].upper()}] {a['code']} – {a['message']}").classes(f"text-xs {c}")

            ui.label(f"Updated {format_time_ago(data['ts'])}").classes("text-xs opacity-50 text-center mt-1")