from nicegui import ui
from core.auth import require_login, is_admin, current_user
from core.locations_repo import list_locations
from core.units_repo import list_units
from ui.layout import layout

def page():
    if not require_login():
        return
    if is_admin():
        ui.navigate.to("/")
        return

    customer_id = current_user().get("client_id")
    
    locations = list_locations(customer_id=customer_id)

    if not locations:
        ui.notify("No locations assigned", type="warning", position="center")
        return

    # Use the unified layout (with back button for non-main pages)
    with layout("My Dashboard", show_logout=True):
        
        # ── Locations Grid ───────────────────────────────────
        ui.label("Your Locations").classes("text-lg font-semibold mb-2")
        
        with ui.grid(columns=3).classes("gap-3 mb-4"):
            for loc in locations:
                loc_title = f"{loc.get('address1','')} — {loc.get('city','')}"
                with ui.card().classes("cursor-pointer p-3 gcc-card hover:shadow-lg transition") as card:
                    card.on("click", lambda l=loc: show_location_equipment(l["ID"], loc_title))
                    ui.label(loc.get('address1','')).classes("text-sm font-semibold").style("color: var(--accent)")
                    ui.label(f"{loc.get('city','')}, {loc.get('state','')}").classes("text-xs opacity-70")

def show_location_equipment(location_id, loc_title):
    units = list_units(location_id=location_id)

    with ui.dialog(value=True) as dlg:
        with ui.card().classes("w-full max-w-2xl gcc-card"):
            with ui.row().classes("justify-between items-center mb-2 pb-2").style("border-bottom: 1px solid var(--line)"):
                ui.label(f"Equipment at {loc_title}").classes("text-base font-bold")
                ui.button(icon="close", on_click=dlg.close).props("flat dense size=sm")

            if not units:
                ui.label("No equipment found in this location.").classes("text-sm opacity-70")
            else:
                with ui.column().classes("gap-2"):
                    for u in units:
                        with ui.card().classes("p-2 cursor-pointer hover:shadow-md transition").style("background: var(--bg); border: 1px solid var(--line)") as card:
                            card.on("click", lambda u=u: (dlg.close(), ui.navigate.to(f"/unit/{u['unit_id']}")))
                            ui.label(f"RTU-{u['unit_id']}").classes("text-sm font-semibold").style("color: var(--accent)")
                            ui.label(f"{u.get('make','')} {u.get('model','')}").classes("text-xs opacity-70")
                            ui.label(f"SN: {u.get('serial','')}").classes("text-xs opacity-50")