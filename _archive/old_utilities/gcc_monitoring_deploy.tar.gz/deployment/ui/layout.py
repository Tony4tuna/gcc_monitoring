from nicegui import ui
from core.auth import current_user, logout

dark_mode = True


def layout(title: str = "GCC Monitoring System", show_logout: bool = False):
    user = current_user()

    # Force dark mode on load
    ui.run_javascript('document.body.classList.remove("light")')

    
    ui.add_head_html("""
    <style>
      :root {
        --bg: #07150f;
        --card: #0b231a;
        --text: #f0f0f0;
        --muted: #aaaaaa;
        --accent: #16a34a;

        --line: rgba(255,255,255,0.14);
        --line-strong: rgba(255,255,255,0.22);
        --border: rgba(255,255,255,0.18);
      }

      body {
        background: var(--bg);
        color: var(--text);
      }

      .gcc-card, .card {
        background: var(--card);
        border: 1px solid var(--line);
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.12);
        color: var(--text) !important;
      }

      .gcc-muted { color: var(--muted) !important; }

      .gcc-soft-grid .q-table__middle td,
      .gcc-soft-grid .q-table__middle th {
        border-color: var(--line) !important;
      }
      .gcc-soft-grid thead tr th {
        border-bottom-color: var(--line-strong) !important;
      }

      .menu-link {
        display: block;
        padding: 8px 12px;
        color: var(--text);
        text-decoration: none;
        border-radius: 8px;
      }
      .menu-link:hover {
        background: var(--accent);
        color: white;
      }

      /* dialogs */
      .q-dialog .q-card,
      .q-dialog .q-dialog__inner > div {
        background: var(--card) !important;
        color: var(--text) !important;
        border: 1px solid var(--line) !important;
      }

      .q-dialog .q-card * {
        color: var(--text) !important;
      }

      /* inputs everywhere */
      input, textarea,
      .q-field__native,
      .q-input input,
      .q-input textarea,
      .q-select__input {
        color: var(--text) !important;
      }

      .q-field__label,
      .q-field__bottom {
        color: var(--muted) !important;
      }

      .q-field__control {
        background: rgba(255,255,255,0.04) !important;
      }

      .q-menu, .q-list {
        background: var(--card) !important;
        color: var(--text) !important;
      }
    </style>
    """)

    # -----------------------------
    # CONFIRM LOGOUT (GLOBAL)
    # -----------------------------
    def confirm_logout():
        with ui.dialog() as d:
            with ui.card().classes("gcc-card p-5"):
                ui.label("Logout?").classes("text-lg font-bold")
                ui.label("You will return to the login screen.")
                with ui.row().classes("justify-end gap-3 mt-4"):
                    ui.button("Cancel", on_click=d.close).props("flat")
                    ui.button(
                        "Logout",
                        on_click=lambda: (d.close(), logout(), ui.navigate.to("/login")),
                    ).props("color=negative")
        d.open()

    # -----------------------------
    # LEFT DRAWER
    # -----------------------------
    with ui.left_drawer(value=True).props("bordered width=260").classes("p-4") as drawer:
        drawer.style("background: var(--card);")

        ui.label(title).classes("text-xl font-bold")
        #ui.label("Dashboard").classes("text-xs gcc-muted -mt-1")

        ui.separator().classes("my-2")

        ui.button("🏠 Home", on_click=lambda: ui.navigate.to("/")).props("glossy outline dense").classes("menu-link w-full").style("border-color: var(--accent); color: var(--accent);")
        
        ui.separator().classes("my-1")

        ui.button("👥 Clients",on_click=lambda: ui.navigate.to("/clients"),).props("glossy outline dense").classes("menu-link w-full").style("border-color: var(--accent); color: var(--accent);")

        ui.button("📍 Locations", on_click=lambda: ui.navigate.to("/locations")).props("glossy outline dense").classes("menu-link w-full").style("border-color: var(--accent); color: var(--accent);")
        ui.button("📦 Units", on_click=lambda: ui.navigate.to("/equipment")).props("glossy outline dense").classes("menu-link w-full").style("border-color: var(--accent); color: var(--accent);")
        
        # AI Cameras Button
        def show_ai_cameras_dialog():
            with ui.dialog() as dialog:
                with ui.card().classes("gcc-card p-5 max-w-2xl"):
                    ui.label("AI Cameras Monitoring").classes("text-lg font-bold mb-4")
                    
                    with ui.row().classes("w-full gap-4 justify-center"):
                        # Frame 1: Compressors, Condenser fans and filters
                        with ui.column():
                            ui.label("📹 Camera 1").classes("text-md font-bold text-center mb-2")
                            with ui.column().classes("w-64 h-64 bg-black rounded").style("border: 2px solid var(--line);"):
                                pass
                        
                        # Frame 2: Evaporator Fan, Belts and Ice evaporator
                        with ui.column():
                            ui.label("📹 Camera 2").classes("text-md font-bold text-center mb-2")
                            with ui.column().classes("w-64 h-64 bg-black rounded").style("border: 2px solid var(--line);"):
                                pass
                    
                    with ui.row().classes("justify-end gap-2 mt-4"):
                        ui.button("Close", on_click=dialog.close).props("flat")
            dialog.open()
        
        ui.button("📹 AI Cameras", on_click=show_ai_cameras_dialog).props("glossy outline dense").classes("menu-link w-full").style("border-color: var(--accent); color: var(--accent);")
        
        # Settings Button
        def show_settings_dialog():
            with ui.dialog() as dialog:
                with ui.card().classes("gcc-card p-5 min-w-96"):
                    ui.label("Settings").classes("text-lg font-bold")
                    ui.label("System settings and configurations (Coming soon)").classes("text-sm gcc-muted")
                    with ui.row().classes("justify-end gap-2 mt-4"):
                        ui.button("Close", on_click=dialog.close).props("flat")
            dialog.open()
        ui.button("🔧 Admin", on_click=lambda: ui.navigate.to("/admin")).props("glossy outline dense").classes("menu-link w-full").style("border-color: var(--accent); color: var(--accent);")

        ui.button("⚙️ Settings", on_click=show_settings_dialog).props("glossy outline dense").classes("menu-link w-full").style("border-color: var(--accent); color: var(--accent);")
        
        
    # -----------------------------
    # HEADER
    # -----------------------------
    with ui.header().classes("items-center justify-between px-4 py-3").style(
        "background: var(--card); border-bottom: 1px solid var(--line);"
    ):
        with ui.row().classes("items-center gap-3"):
            ui.button("☰", on_click=drawer.toggle).props("flat dense").style(
                "font-size: 24px; color: var(--text);"
            )
            ui.label("GCC Tech. Motoring System").classes("text-lg font-bold")

        with ui.row().classes("items-center gap-4 ml-auto"):
            if user:
                ui.label(user.get("email", "Guest")).classes("text-sm gcc-muted")

            if show_logout:
                ui.button("Logout", on_click=confirm_logout).props("flat")
            else:
                ui.button(icon="arrow_back", on_click=lambda: ui.navigate.back()).props("flat dense").style(
                    "color: var(--text);"
                )

    # -----------------------------
    # PAGE CONTENT CONTAINER
    # -----------------------------
    return ui.column().classes("p-5 w-full max-w-[1300px] mx-auto gap-6")
